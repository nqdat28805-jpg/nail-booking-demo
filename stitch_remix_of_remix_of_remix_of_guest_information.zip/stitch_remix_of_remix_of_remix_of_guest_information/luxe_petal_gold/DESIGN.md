# Design System Strategy: The Tactile Atelier

## 1. Overview & Creative North Star
**Creative North Star: The Curated Sanctuary**
This design system moves away from the sterile, "dashboard-as-a-spreadsheet" aesthetic typical of management software. Instead, it treats the salon interface as a digital extension of the physical luxury space—intentional, airy, and tactile.

We reject the rigid, boxy constraints of traditional UI. Our approach utilizes **Asymmetric Balance** and **Layered Sophistication**. By using expansive whitespace and editorial typography, we transform functional salon tasks (booking, inventory, payroll) into a premium experience. The goal is to make the technician feel like an artisan and the owner feel like a curator.

---

## 2. Color: The Tonal Landscape
The palette is grounded in warmth and skin-toned neutrals, accented by sophisticated metallics and high-clarity functional tones.

### The "No-Line" Rule
**Strict Mandate:** 1px solid borders for sectioning are prohibited. Boundaries must be defined solely through background color shifts or subtle tonal transitions.
- Use `surface_container_low` sections sitting on a `surface` background to denote distinct areas.
- For nested elements, use the `surface_container_highest` against `surface_container`.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—stacked sheets of fine parchment.
- **Base Layer:** `surface` (#FDF9F6) for the overall application background.
- **Secondary Layer:** `surface_container` (#F1EDEA) for sidebars or navigation drawers.
- **Hero/Action Layer:** `surface_container_lowest` (#FFFFFF) for primary work cards to provide maximum "pop" and focus.

### The Glass & Gradient Rule
To achieve a signature feel, floating elements (like "Book Now" FABs or Quick-Action menus) must use **Glassmorphism**:
- Background: `surface_container_lowest` at 80% opacity.
- Backdrop-blur: `12px` to `20px`.
- Use a subtle linear gradient on primary CTAs: `primary` (#7F5253) to `primary_container` (#D9A2A2) at a 135-degree angle to provide a velvet-like depth.

---

## 3. Typography: Editorial Authority
The typography system balances the timeless elegance of Noto Serif with the high-performance legibility of Manrope.

*   **Display & Headlines (Noto Serif):** Used for "Momentum Moments"—the salon name, daily revenue totals, or technician names. These should feel like headers in a high-end fashion magazine.
*   **Body & Titles (Manrope):** Used for all functional data. Manrope’s geometric clarity ensures that even small text on a moving tablet is legible.
*   **Contrast is King:** All body text must utilize `on_surface` (#1C1B1A) for maximum readability against neutral backgrounds.

---

## 4. Elevation & Depth: Tonal Layering
We do not use shadows to simulate height; we use light and opacity.

*   **The Layering Principle:** Place a `surface_container_lowest` card on a `surface_container_low` section. This creates a "soft lift" that feels organic rather than artificial.
*   **Ambient Shadows:** If a floating element (like a modal) requires a shadow, it must be:
    *   `X: 0, Y: 8, Blur: 32, Spread: 0`
    *   Color: `on_surface` (#1C1B1A) at **6% opacity**.
*   **The "Ghost Border" Fallback:** For accessibility in form fields, use a "Ghost Border": `outline_variant` (#D5C2C2) at **20% opacity**. Never use a 100% opaque border.

---

## 5. Components: Tactile & Intentional

### Buttons (Touch-First)
All buttons must have a minimum height of **56px** to accommodate fast-paced salon environments.
- **Primary:** Gradient fill (`primary` to `primary_container`), white text, `xl` (1.5rem) roundedness.
- **Secondary:** `surface_container_highest` fill, `on_surface` text. No border.

### Cards & Lists: The Separation Rule
**Forbid the use of divider lines.**
- Separate appointment cards using `md` (0.75rem) vertical spacing.
- Use a subtle background shift (e.g., a `tertiary_container` pill) to highlight "Success" or "Active" states instead of a stroke.

### Input Fields
- Background: `surface_container_low`.
- Active State: A bottom-only "thick" indicator (3px) in `secondary` (#775A19) rather than a full box stroke.
- Labels must use `label-md` in `on_surface_variant` for a sophisticated, understated look.

### Salon-Specific Components
- **The Service Ribbon:** A horizontal scrolling list of service chips (e.g., "Gel Manicure," "Acrylic Fill") using `surface_container_lowest` with `md` roundedness.
- **The Technician Gauge:** A circular progress indicator using `tertiary` (#2C694E) to show daily booking capacity.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use `tertiary` (#2C694E) for "Paid" or "Complete" statuses—it suggests growth and calm.
- **Do** embrace asymmetry. An image of a nail set can overlap the edge of a card to break the "grid" feel.
- **Do** prioritize the `surface_bright` tone for the owner's view to convey a sense of high-level clarity and "The Big Picture."

### Don’t:
- **Don't** use pure black (#000000). Always use `on_surface` (#1C1B1A) for a softer, premium feel.
- **Don't** use standard "Warning Yellow." Use `secondary` (#775A19) or `secondary_container` for warnings to keep them within the gold/earth-tone brand family.
- **Don't** pack information tightly. If a screen feels full, increase the `surface` padding. Luxury is defined by the space you *don't* fill.